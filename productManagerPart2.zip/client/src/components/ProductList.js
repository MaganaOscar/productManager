import React from 'react';
import { Link } from '@reach/router';
export default props => {
    return (
        <div>
            <h2>All Products: </h2>
            {props.products.map((product)=>{
                return (<Link to ={`${product._id}`}><p>{product.title}</p></Link>)
            })}
        </div>
    )
}